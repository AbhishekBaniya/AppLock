package com.example.lasttry.helper;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Vibrator;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.core.content.ContextCompat;

import com.example.lasttry.R;
import com.example.lasttry.utils.SettingsKeys;

@RequiresApi(api = Build.VERSION_CODES.M)
public class FingerprintHandler extends FingerprintManager.AuthenticationCallback{
    private Context context;

    public FingerprintHandler(Context context){
        this.context = context;
    }

    public void startAuth(FingerprintManager fingerprintManager, FingerprintManager.CryptoObject cryptoObject){

        CancellationSignal cancellationSignal = new CancellationSignal();
        fingerprintManager.authenticate(cryptoObject, cancellationSignal, 0, this, null);

    }

    @Override
    public void onAuthenticationError(int errorCode, CharSequence errString) {

        this.update("There was an Auth Error. " + errString, false);

    }

    @Override
    public void onAuthenticationFailed() {

        this.update("Auth Failed. ", false);

    }

    @Override
    public void onAuthenticationHelp(int helpCode, CharSequence helpString) {

        this.update("Error: " + helpString, false);

    }

    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {

        this.update("You can now access the app.", true);

    }

    private void update(String s, boolean b) {

        TextView paraLabel = (TextView) ((Activity)context).findViewById(R.id.tv_fingerprint);
        ImageView imageView = (ImageView) ((Activity)context).findViewById(R.id.img_fingerprint);
        Vibrator vibe = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);

        paraLabel.setText(s);

        if(b == false){

            paraLabel.setTextColor(ContextCompat.getColor(context, R.color.white));
            vibe.vibrate(100);

        } else {

            paraLabel.setTextColor(ContextCompat.getColor(context, R.color.white));
            unlock();
        }
    }

    protected void unlock(){
        Helper mHelper = new Helper(context);
        Intent mIntent = ((Activity) context).getIntent();

        if (mIntent != null && mIntent.getStringExtra(SettingsKeys.PREVIOUS_ACTIVITY) != null && mIntent.getStringExtra(SettingsKeys.PREVIOUS_ACTIVITY).equals(SettingsKeys.EXTERNAL_ACTIVITY)) {
            String appName = mIntent.getStringExtra(SettingsKeys.APP_LAUNCH);
            Log.i("PinSuccess", "Boom");
            mHelper.editSharedPref(SettingsKeys.TEMP_UNLOCK, true);
            Log.i("TEMP", "Temporary unlock is enabled");

            mHelper.setCurrentActivity(appName);
            mHelper.startActivity(appName);
        }
    }
}
