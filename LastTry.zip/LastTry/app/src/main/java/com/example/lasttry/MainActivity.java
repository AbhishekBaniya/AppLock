package com.example.lasttry;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lasttry.adapter.AppListAdapter;
import com.example.lasttry.helper.Helper;
import com.example.lasttry.model.InstalledAppList;
import com.example.lasttry.utils.SettingsKeys;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    protected TextView tv_appLock_status, tv_total_no_block_apps;
    protected CheckBox cb_img_app_lock_status;
    protected RecyclerView rv_appList;
    protected AppListAdapter adapter;
    protected LinearLayoutManager layoutManager;
    protected List<InstalledAppList> apps;
    private Helper mHelper;
    protected Boolean isStatusOn, selfChecked;
    protected SharedPreferences sp;
    protected RecyclerView.ItemDecoration itemDecoration;
    protected int totalLocked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }else {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        getSupportActionBar().hide();


        tv_appLock_status = findViewById(R.id.tv_appLock_status);
        tv_total_no_block_apps = findViewById(R.id.tv_total_no_block_apps);
        cb_img_app_lock_status = findViewById(R.id.cb_img_app_lock_status);
        rv_appList = findViewById(R.id.rv_appList);

        sp = getSharedPreferences("status", MODE_PRIVATE);

        SharedPreferences.Editor editor = sp.edit();

        layoutManager = new LinearLayoutManager(this);
        rv_appList.setClickable(true);
        rv_appList.setHasFixedSize(true);
        rv_appList.setLayoutManager(layoutManager);
        itemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        rv_appList.addItemDecoration(itemDecoration);
        adapter = new AppListAdapter(getApplicationContext());

        getChecked();

        totalLockedApps();

        if (selfChecked == true){
            cb_img_app_lock_status.setChecked(true);
            tv_appLock_status.setText("App Lock Status : On");
        } else {
            cb_img_app_lock_status.setChecked(false);
            tv_appLock_status.setText("App Lock Status : Off");
        }

        mHelper = new Helper(getApplicationContext());
        if(!mHelper.isAccessibilitySettingsOn())
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setCancelable(false);
            builder.setTitle("Accessibility is disabled");
            builder.setMessage("Open Settings and enable AppLock accessibility service");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Intent intent = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    startActivityForResult(intent,0);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    finish();
                }
            });
            builder.show();
        }

        cb_img_app_lock_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(((CompoundButton) v).isChecked()){
                    System.out.println("Checked");
                    tv_appLock_status.setText("App Lock Status : On");
                    isStatusOn = true;
                    editor.putBoolean("status", isStatusOn);
                    editor.apply();
                } else {
                    System.out.println("Un-Checked");
                    tv_appLock_status.setText("App Lock Status : Off");
                    isStatusOn = false;
                    editor.putBoolean("status", isStatusOn);
                    editor.apply();
                }
            }
        });
        new LoadApplications().execute();
    }


    private List<InstalledAppList> getInstalledApps() {
        PackageManager pm = getPackageManager();
        apps = new ArrayList<InstalledAppList>();
        Intent main=new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> launchables=pm.queryIntentActivities(main, 0);
        Collections.sort(launchables, new ResolveInfo.DisplayNameComparator(pm));
        for (ResolveInfo ri : launchables){

           try {
                /* Slower app startup, but fewer apps for the user to go through */
                PackageInfo pkgInfo = pm.getPackageInfo(ri.activityInfo.applicationInfo.packageName, PackageManager.GET_ACTIVITIES);
                ActivityInfo[] list = pkgInfo.activities;
                if (list != null) {
                    if (null != pm.getLaunchIntentForPackage(ri.activityInfo.applicationInfo.packageName)) {
                        if(!ri.activityInfo.applicationInfo.packageName.equals("com.example.lasttry") && !ri.activityInfo.applicationInfo.packageName.equals("com.eScan.main")){
                            apps.add(new InstalledAppList(ri.activityInfo.applicationInfo.loadIcon(pm),ri.activityInfo.applicationInfo.loadLabel(pm).toString(), ri.activityInfo.applicationInfo.packageName));
                        }
                    }
                }
            } catch (Exception e) {
                continue;
            }
        }
        return apps;
    }

    public class LoadApplications extends AsyncTask<Void, Void, Void> {
        protected ProgressDialog pd = null;

        @Override
        protected void onPreExecute() {
            //pd = ProgressDialog.show(getApplicationContext(), null, "Loading app info ...");
            pd = new ProgressDialog(MainActivity.this);
            pd.setCancelable(false);
            pd.setMessage("please wait...");
            pd.show();
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {
            getInstalledApps();
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            rv_appList.setAdapter(adapter);
            adapter.setData(apps);
            adapter.notifyDataSetChanged();
            pd.dismiss();
        }
    }

    protected void getChecked(){
        SharedPreferences  sp = getSharedPreferences("status", MODE_PRIVATE);
        selfChecked = sp.getBoolean("status", false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        totalLockedApps();
    }

    protected void totalLockedApps(){
        SharedPreferences sp1 = getSharedPreferences("Total_Locked", MODE_PRIVATE);
        totalLocked = sp1.getInt("count", 0);
        Toast.makeText(this, ""+totalLocked, Toast.LENGTH_SHORT).show();
        tv_total_no_block_apps.setText("Total Locked App(s)"+ totalLocked);
    }
}