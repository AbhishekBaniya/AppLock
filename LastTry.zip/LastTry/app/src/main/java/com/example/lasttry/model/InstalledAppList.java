package com.example.lasttry.model;

import android.graphics.drawable.Drawable;

public class InstalledAppList {
    protected Drawable appIcon;
    protected String name;
    protected String packages;
    protected String count;


    public InstalledAppList(Drawable appIcon,  String name, String packages) {
        this.appIcon = appIcon;
        this.name = name;
        this.packages = packages;
    }

    public Drawable getAppIcon() {
        return appIcon;
    }

    public void setAppIcon(Drawable appIcon) {
        this.appIcon = appIcon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPackages() {
        return packages;
    }

    public void setPackages(String packages) {
        this.packages = packages;
    }
}