package com.example.lasttry;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.hardware.fingerprint.FingerprintManager;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.lasttry.helper.FingerprintHandler;
import com.example.lasttry.helper.Helper;
import com.example.lasttry.utils.SettingsKeys;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

@RequiresApi(api = Build.VERSION_CODES.M)
public class PassCodeActivity extends AppCompatActivity {
    protected Helper mHelper;
    protected Button btnEnter;
    protected ImageView logoImage;
    protected EditText et_custom_pass;
    protected TextView tv_indication;
    protected String admin_pass = "1111";

    private TextView mHeadingLabel;
    private ImageView mFingerprintImage;
    private TextView mParaLabel;

    private FingerprintManager fingerprintManager;
    private KeyguardManager keyguardManager;

    private KeyStore keyStore;
    private Cipher cipher;
    private String KEY_NAME = "AndroidKey";
    FingerprintHandler fingerprintHandler;


    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_code);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }else {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        getSupportActionBar().hide();

        mHelper = new Helper(getApplicationContext());
        logoImage = findViewById(R.id.logo_imageview);
        tv_indication = findViewById(R.id.tv_indication);
        et_custom_pass = findViewById(R.id.et_custom_pass);
        btnEnter = findViewById(R.id.btnEnter);
        btnEnter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unlock();
            }
        });
        initLayout(getIntent());

       /* et_custom_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                // TODO Auto-generated method stub
                //unlock();
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                // TODO Auto-generated method stub
                logoImage.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake));
            }

            @Override
            public void afterTextChanged(Editable s) {

                // TODO Auto-generated method stub
                logoImage.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake));
            }
        });*/
    }


    public void btnClick(View v) {
        tv_indication.setText("");
        int i = Integer.parseInt(((TextView) v).getText().toString().trim());
        et_custom_pass.dispatchKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, 7 + i));
    }

    public void clearClick(View v) {
        KeyEvent event = new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL);
        et_custom_pass.dispatchKeyEvent(event);
    }

    public void onCloseClick(View v) {
        Log.d("OnBack", "Go To Home Screen");
        Intent setIntent = new Intent(Intent.ACTION_MAIN);
        setIntent.addCategory(Intent.CATEGORY_HOME);
        setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(setIntent);
    }

    private void initLayout(Intent intent) {
        Intent mIntent = intent;
        if (mIntent.getStringExtra(SettingsKeys.PREVIOUS_ACTIVITY) != null && mIntent.getStringExtra(SettingsKeys.PREVIOUS_ACTIVITY).equals(SettingsKeys.EXTERNAL_ACTIVITY)) {
            String appName = mIntent.getStringExtra(SettingsKeys.APP_LAUNCH);
            try {
                assert appName != null;
                Drawable icon = getPackageManager().getApplicationIcon(appName);
                logoImage.setImageDrawable(icon);
            } catch (Exception e) {

            }

        }

    }

    protected void unlock(){
        String password = et_custom_pass.getText().toString();

        if (password.isEmpty()){
            tv_indication.setText("Please Enter The Code");
            logoImage.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake));
        } else if(password.length() > 0){
            if(admin_pass.equals(password.trim())){
                //Toast.makeText(getApplicationContext(), "CORRECT", Toast.LENGTH_SHORT).show();
                tv_indication.setText("");
                mHelper = new Helper(getApplicationContext());
                Intent mIntent = getIntent();

                if (mIntent != null && mIntent.getStringExtra(SettingsKeys.PREVIOUS_ACTIVITY) != null && mIntent.getStringExtra(SettingsKeys.PREVIOUS_ACTIVITY).equals(SettingsKeys.EXTERNAL_ACTIVITY)) {
                    String appName = mIntent.getStringExtra(SettingsKeys.APP_LAUNCH);
                    Log.i("PinSuccess", "Boom");
                    mHelper.editSharedPref(SettingsKeys.TEMP_UNLOCK, true);
                    Log.i("TEMP", "Temporary unlock is enabled");

                    mHelper.setCurrentActivity(appName);
                    mHelper.startActivity(appName);
                    et_custom_pass.setText("");
                }

            }else{
                //Toast.makeText(getApplicationContext(), "INCORRECT", Toast.LENGTH_SHORT).show();
                tv_indication.setText("Secret Code Does Not Matched");
                et_custom_pass.setText("");
                logoImage.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake));
            }
        }else{
            Log.i("testing_pin","Length is short");
            et_custom_pass.setText("");
            logoImage.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.shake));
        }
    }

    protected void authFingerPrint(){
        /*mHeadingLabel = (TextView) findViewById(R.id.headingLabel);*/
        mFingerprintImage = (ImageView) findViewById(R.id.img_fingerprint);
        mParaLabel = (TextView) findViewById(R.id.tv_fingerprint);

        // Check 1: Android version should be greater or equal to Marshmallow
        // Check 2: Device has Fingerprint Scanner
        // Check 3: Have permission to use fingerprint scanner in the app
        // Check 4: Lock screen is secured with atleast 1 type of lock
        // Check 5: Atleast 1 Fingerprint is registered

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            fingerprintManager = (FingerprintManager) getSystemService(FINGERPRINT_SERVICE);
            keyguardManager = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);

            if(!fingerprintManager.isHardwareDetected()){
                mParaLabel.setVisibility(View.GONE);
                mParaLabel.setText("Fingerprint Scanner not detected in Device");

            } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.USE_FINGERPRINT) != PackageManager.PERMISSION_GRANTED){

                mParaLabel.setText("Permission not granted to use Fingerprint Scanner");

            } else if (!keyguardManager.isKeyguardSecure()){

                mParaLabel.setText("Add Lock to your Phone in Settings");

            } else if (!fingerprintManager.hasEnrolledFingerprints()){

                mParaLabel.setText("You should add atleast 1 Fingerprint to use this Feature");

            } else {

                mParaLabel.setText("Place your Finger on Scanner to Access the App.");

                generateKey();

                if (cipherInit()){

                    FingerprintManager.CryptoObject cryptoObject = new FingerprintManager.CryptoObject(cipher);
                    fingerprintHandler = new FingerprintHandler(this);
                    fingerprintHandler.startAuth(fingerprintManager, cryptoObject);

                }
            }

        }
    }

    @TargetApi(Build.VERSION_CODES.M)
    private void generateKey() {

        try {

            keyStore = KeyStore.getInstance("AndroidKeyStore");
            KeyGenerator keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");

            keyStore.load(null);
            keyGenerator.init(new
                    KeyGenParameterSpec.Builder(KEY_NAME,
                    KeyProperties.PURPOSE_ENCRYPT |
                            KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_CBC)
                    .setUserAuthenticationRequired(true)
                    .setEncryptionPaddings(
                            KeyProperties.ENCRYPTION_PADDING_PKCS7)
                    .build());
            keyGenerator.generateKey();

        } catch (KeyStoreException | IOException | CertificateException
                | NoSuchAlgorithmException | InvalidAlgorithmParameterException
                | NoSuchProviderException e) {

            e.printStackTrace();

        }

    }

    @TargetApi(Build.VERSION_CODES.M)
    public boolean cipherInit() {
        try {
            cipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/" + KeyProperties.BLOCK_MODE_CBC + "/" + KeyProperties.ENCRYPTION_PADDING_PKCS7);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            throw new RuntimeException("Failed to get Cipher", e);
        }


        try {

            keyStore.load(null);

            SecretKey key = (SecretKey) keyStore.getKey(KEY_NAME,
                    null);

            cipher.init(Cipher.ENCRYPT_MODE, key);

            return true;

        } catch (KeyPermanentlyInvalidatedException e) {
            return false;
        } catch (KeyStoreException | CertificateException | UnrecoverableKeyException | IOException | NoSuchAlgorithmException | InvalidKeyException e) {
            throw new RuntimeException("Failed to init Cipher", e);
        }
    }
}